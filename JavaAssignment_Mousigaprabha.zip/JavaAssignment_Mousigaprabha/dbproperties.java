db.url=jdbc:mysql://localhost:3306/TechShop
db.name=TechShop
db.username=root
db.password=root