// Order.java
package entity;

import java.time.LocalDateTime;
import java.util.List;

public class Order {
    private int orderID;
    private Customer customer;
    private LocalDateTime orderDate;
    private double totalAmount;
    private String status;
    private List<OrderDetail> orderDetails;

    // Constructors
    public Order() {}

    public Order(int orderID, Customer customer, LocalDateTime orderDate, 
                double totalAmount, String status) {
        this.orderID = orderID;
        this.customer = customer;
        this.orderDate = orderDate;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    // Getters and setters
    public int getOrderID() { return orderID; }
    public void setOrderID(int orderID) { this.orderID = orderID; }

    public Customer getCustomer() { return customer; }
    public void setCustomer(Customer customer) { 
        if (customer == null) {
            throw new IllegalArgumentException("Customer cannot be null");
        }
        this.customer = customer; 
    }

    public LocalDateTime getOrderDate() { return orderDate; }
    public void setOrderDate(LocalDateTime orderDate) { this.orderDate = orderDate; }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { 
        if (totalAmount < 0) {
            throw new IllegalArgumentException("Total amount cannot be negative");
        }
        this.totalAmount = totalAmount; 
    }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public List<OrderDetail> getOrderDetails() { return orderDetails; }
    public void setOrderDetails(List<OrderDetail> orderDetails) { this.orderDetails = orderDetails; }

    // Methods
    public void calculateTotalAmount() {
        if (orderDetails == null || orderDetails.isEmpty()) {
            totalAmount = 0;
            return;
        }
        
        totalAmount = orderDetails.stream()
            .mapToDouble(OrderDetail::calculateSubtotal)
            .sum();
    }

    public void getOrderDetailsInfo() {
    	System.out.println("Order ID: " + orderID);
    	System.out.println("Customer: " + customer.getFirstName() + " " + customer.getLastName());
    	System.out.println("Order Date: " + orderDate);
    	System.out.println("Status: " + status);
    	System.out.println("Total Amount: $" + totalAmount);

    	if (orderDetails != null && !orderDetails.isEmpty()) {
    	    System.out.println("\nOrder Items:");
    	    for (OrderDetail detail : orderDetails) {
    	        detail.getOrderDetailInfo();
    	        System.out.println("---");
    	    }
    	}
    }
    	public void updateOrderStatus(String newStatus) {
    	    setStatus(newStatus);
    	}
    	
    }
