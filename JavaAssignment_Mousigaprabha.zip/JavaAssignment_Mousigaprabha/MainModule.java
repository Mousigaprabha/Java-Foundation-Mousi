package main;

import java.util.Scanner;
import dao.TechShopService;
import dao.TechShopServiceImpl;
import entity.Customer;
import entity.Product;
import exception.InvalidDataException;

public class MainModule {
    private static TechShopService techShopService = new TechShopServiceImpl();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean exit = false;
        
        while (!exit) {
            System.out.println("\n===== TechShop Management System =====");
            System.out.println("1. Customer Management");
            System.out.println("2. Product Management");
            System.out.println("3. Order Management");
            System.out.println("4. Inventory Management");
            System.out.println("5. Reports");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            switch (choice) {
                case 1:
                    customerManagement();
                    break;
                case 2:
                    productManagement();
                    break;
                case 3:
                    orderManagement();
                    break;
                case 4:
                    inventoryManagement();
                    break;
                case 5:
                    reportManagement();
                    break;
                case 0:
                    exit = true;
                    System.out.println("Exiting system...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        
        scanner.close();
    }

    private static void customerManagement() {
        boolean back = false;
        
        while (!back) {
            System.out.println("\n===== Customer Management =====");
            System.out.println("1. Add New Customer");
            System.out.println("2. View Customer Details");
            System.out.println("3. Update Customer Information");
            System.out.println("4. List All Customers");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();
            
            switch (choice) {
                case 1:
                    addCustomer();
                    break;
                case 2:
                    viewCustomer();
                    break;
                case 3:
                    updateCustomer();
                    break;
                case 4:
                    listAllCustomers();
                    break;
                case 0:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addCustomer() {
        System.out.println("\n===== Add New Customer =====");
        Customer customer = new Customer();
        
        System.out.print("Enter First Name: ");
        customer.setFirstName(scanner.nextLine());
        
        System.out.print("Enter Last Name: ");
        customer.setLastName(scanner.nextLine());
        
        System.out.print("Enter Email: ");
        customer.setEmail(scanner.nextLine());
        
        System.out.print("Enter Phone: ");
        customer.setPhone(scanner.nextLine());
        
        System.out.print("Enter Address: ");
        customer.setAddress(scanner.nextLine());
        
        try {
            techShopService.addCustomer(customer);
            System.out.println("Customer added successfully!");
        } catch (InvalidDataException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewCustomer() {
        System.out.print("\nEnter Customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        
        Customer customer = techShopService.getCustomerById(customerId);
        if (customer != null) {
            customer.getCustomerDetails();
        } else {
            System.out.println("Customer not found with ID: " + customerId);
        }
    }

    private static void updateCustomer() {
        System.out.print("\nEnter Customer ID to update: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        
        Customer customer = techShopService.getCustomerById(customerId);
        if (customer == null) {
            System.out.println("Customer not found with ID: " + customerId);
            return;
        }
        
        System.out.println("\nCurrent Customer Information:");
        customer.getCustomerDetails();
        
        System.out.println("\nEnter new information (leave blank to keep current):");
        
        System.out.print("New Email: ");
        String email = scanner.nextLine();
        if (!email.isEmpty()) customer.setEmail(email);
        
        System.out.print("New Phone: ");
        String phone = scanner.nextLine();
        if (!phone.isEmpty()) customer.setPhone(phone);
        
        System.out.print("New Address: ");
        String address = scanner.nextLine();
        if (!address.isEmpty()) customer.setAddress(address);
        
        try {
            techShopService.updateCustomer(customer);
            System.out.println("Customer updated successfully!");
        } catch (InvalidDataException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void listAllCustomers() {
        System.out.println("\n===== All Customers =====");
        techShopService.getAllCustomers().forEach(customer -> {
            customer.getCustomerDetails();
            System.out.println("---------------------");
        });
    }

    // Implement similar methods for productManagement(), orderManagement(), etc.
    // Following the same pattern as customerManagement()
    
    private static void productManagement() {
        // Implement product management menu and operations
    }
    
    private static void orderManagement() {
        // Implement order management menu and operations
    }
    
    private static void inventoryManagement() {
        // Implement inventory management menu and operations
    }
    
    private static void reportManagement() {
        // Implement report generation menu and operations
    }
}