// TechShopService.java
package dao;

import java.util.List;

import entity.Customer;
import entity.Inventory;
import entity.Order;
import entity.OrderDetail;
import entity.Product;
import exception.IncompleteOrderException;
import exception.InsufficientStockException;
import exception.InvalidDataException;

public interface TechShopService {
    // Customer operations
    void addCustomer(Customer customer) throws InvalidDataException;
    Customer getCustomerById(int customerId);
    List<Customer> getAllCustomers();
    void updateCustomer(Customer customer) throws InvalidDataException;
    void deleteCustomer(int customerId);
    
    // Product operations
    void addProduct(Product product) throws InvalidDataException;
    Product getProductById(int productId);
    List<Product> getAllProducts();
    void updateProduct(Product product) throws InvalidDataException;
    void deleteProduct(int productId);
    
    // Order operations
    void placeOrder(Order order) throws IncompleteOrderException, InsufficientStockException;
    Order getOrderById(int orderId);
    List<Order> getOrdersByCustomer(int customerId);
    void updateOrderStatus(int orderId, String status);
    void cancelOrder(int orderId);
    
    // OrderDetail operations
    void addOrderDetail(OrderDetail orderDetail) throws IncompleteOrderException;
    List<OrderDetail> getOrderDetails(int orderId);
    
    // Inventory operations
    void updateInventory(Inventory inventory);
    Inventory getInventoryByProduct(int productId);
    List<Inventory> getLowStockProducts(int threshold);
    List<Inventory> getOutOfStockProducts();
    
    // Reporting operations
    double getTotalRevenue();
    List<Product> getTopSellingProducts(int limit);
    double getCustomerTotalSpending(int customerId);
}