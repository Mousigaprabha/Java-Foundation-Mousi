// OrderDetail.java
package entity;

public class OrderDetail {
    private int orderDetailID;
    private Order order;
    private Product product;
    private int quantity;
    private double discount;

    // Constructors
    public OrderDetail() {}

    public OrderDetail(int orderDetailID, Order order, Product product, int quantity) {
        this.orderDetailID = orderDetailID;
        this.order = order;
        this.product = product;
        this.quantity = quantity;
        this.discount = 0;
    }

    // Getters and setters with validation
    public int getOrderDetailID() { return orderDetailID; }
    public void setOrderDetailID(int orderDetailID) { this.orderDetailID = orderDetailID; }

    public Order getOrder() { return order; }
    public void setOrder(Order order) { 
        if (order == null) {
            throw new IllegalArgumentException("Order cannot be null");
        }
        this.order = order; 
    }

    public Product getProduct() { return product; }
    public void setProduct(Product product) { 
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null");
        }
        this.product = product; 
    }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { 
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        this.quantity = quantity; 
    }

    public double getDiscount() { return discount; }
    public void setDiscount(double discount) { 
        if (discount < 0 || discount > 100) {
            throw new IllegalArgumentException("Discount must be between 0 and 100");
        }
        this.discount = discount; 
    }

    // Methods
    public double calculateSubtotal() {
        double subtotal = product.getPrice() * quantity;
        return subtotal * (1 - discount / 100);
    }

    public void getOrderDetailInfo() {
        System.out.println("Order Detail ID: " + orderDetailID);
        System.out.println("Product: " + product.getProductName());
        System.out.println("Quantity: " + quantity);
        System.out.println("Price per unit: $" + product.getPrice());
        System.out.println("Discount: " + discount + "%");
        System.out.println("Subtotal: $" + calculateSubtotal());
    }

    public void updateQuantity(int newQuantity) {
        setQuantity(newQuantity);
    }

    public void addDiscount(double discountPercentage) {
        setDiscount(discountPercentage);
    }
}