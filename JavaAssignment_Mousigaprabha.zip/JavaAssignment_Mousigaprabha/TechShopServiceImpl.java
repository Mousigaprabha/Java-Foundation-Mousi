// TechShopServiceImpl.java
package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import entity.*;
import exception.*;
import util.DBConnUtil;
import util.DBPropertyUtil;

public class TechShopServiceImpl implements TechShopService {
    private Connection connection;
    
    public TechShopServiceImpl() {
        try {
            String connectionString = DBPropertyUtil.getConnectionString("config.properties");
            this.connection = DBConnUtil.getConnection(connectionString);
        } catch (SQLException e) {
            System.err.println("Error establishing database connection: " + e.getMessage());
        }
    }
    
    @Override
    public void addCustomer(Customer customer) throws InvalidDataException {
        String sql = "INSERT INTO Customers (FirstName, LastName, Email, Phone, Address) VALUES (?, ?, ?, ?, ?)";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, customer.getFirstName());
            stmt.setString(2, customer.getLastName());
            stmt.setString(3, customer.getEmail());
            stmt.setString(4, customer.getPhone());
            stmt.setString(5, customer.getAddress());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating customer failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    customer.setCustomerID(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating customer failed, no ID obtained.");
                }
            }
        } catch (SQLException e) {
            if (e.getMessage().contains("Duplicate entry") && e.getMessage().contains("Email")) {
                throw new InvalidDataException("Email address already exists");
            }
            throw new RuntimeException("Error adding customer", e);
        }
    }
    
    @Override
    public Customer getCustomerById(int customerId) {
        String sql = "SELECT * FROM Customers WHERE CustomerID = ?";
        Customer customer = null;
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    customer = new Customer(
                        rs.getInt("CustomerID"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("Email"),
                        rs.getString("Phone"),
                        rs.getString("Address")
                    );
                    customer.setOrderCount(rs.getInt("OrderCount"));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving customer", e);
        }
        
        return customer;
    }
    
    @Override
    public List<Customer> getAllCustomers() {
        String sql = "SELECT * FROM Customers";
        List<Customer> customers = new ArrayList<>();
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Customer customer = new Customer(
                    rs.getInt("CustomerID"),
                    rs.getString("FirstName"),
                    rs.getString("LastName"),
                    rs.getString("Email"),
                    rs.getString("Phone"),
                    rs.getString("Address")
                );
                customer.setOrderCount(rs.getInt("OrderCount"));
                customers.add(customer);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving customers", e);
        }
        
        return customers;
    }
    
    @Override
    public void updateCustomer(Customer customer) throws InvalidDataException {
        String sql = "UPDATE Customers SET FirstName = ?, LastName = ?, Email = ?, Phone = ?, Address = ? WHERE CustomerID = ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, customer.getFirstName());
            stmt.setString(2, customer.getLastName());
            stmt.setString(3, customer.getEmail());
            stmt.setString(4, customer.getPhone());
            stmt.setString(5, customer.getAddress());
            stmt.set

	@Override
	public void deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addProduct(Product product) throws InvalidDataException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Product getProductById(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateProduct(Product product) throws InvalidDataException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProduct(int productId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void placeOrder(Order order) throws IncompleteOrderException, InsufficientStockException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Order getOrderById(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> getOrdersByCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateOrderStatus(int orderId, String status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cancelOrder(int orderId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addOrderDetail(OrderDetail orderDetail) throws IncompleteOrderException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<OrderDetail> getOrderDetails(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateInventory(Inventory inventory) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Inventory getInventoryByProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Inventory> getLowStockProducts(int threshold) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Inventory> getOutOfStockProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getTotalRevenue() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Product> getTopSellingProducts(int limit) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getCustomerTotalSpending(int customerId) {
		// TODO Auto-generated method stub
		return 0;
	}