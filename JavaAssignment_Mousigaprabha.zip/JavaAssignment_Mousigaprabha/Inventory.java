// Inventory.java
package entity;

import java.time.LocalDateTime;
import java.util.List;

public class Inventory {
    private int inventoryID;
    private Product product;
    private int quantityInStock;
    private LocalDateTime lastStockUpdate;

    // Constructors
    public Inventory() {}

    public Inventory(int inventoryID, Product product, int quantityInStock, LocalDateTime lastStockUpdate) {
        this.inventoryID = inventoryID;
        this.product = product;
        this.quantityInStock = quantityInStock;
        this.lastStockUpdate = lastStockUpdate;
    }

    // Getters and setters with validation
    public int getInventoryID() { return inventoryID; }
    public void setInventoryID(int inventoryID) { this.inventoryID = inventoryID; }

    public Product getProduct() { return product; }
    public void setProduct(Product product) { 
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null");
        }
        this.product = product; 
    }

    public int getQuantityInStock() { return quantityInStock; }
    public void setQuantityInStock(int quantityInStock) { 
        if (quantityInStock < 0) {
            throw new IllegalArgumentException("Quantity cannot be negative");
        }
        this.quantityInStock = quantityInStock; 
    }

    public LocalDateTime getLastStockUpdate() { return lastStockUpdate; }
    public void setLastStockUpdate(LocalDateTime lastStockUpdate) { 
        this.lastStockUpdate = lastStockUpdate; 
    }

    // Methods
    public void addToInventory(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        quantityInStock += quantity;
        lastStockUpdate = LocalDateTime.now();
    }

    public void removeFromInventory(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        if (quantity > quantityInStock) {
            throw new IllegalArgumentException("Insufficient stock");
        }
        quantityInStock -= quantity;
        lastStockUpdate = LocalDateTime.now();
    }

    public void updateStockQuantity(int newQuantity) {
        if (newQuantity < 0) {
            throw new IllegalArgumentException("Quantity cannot be negative");
        }
        quantityInStock = newQuantity;
        lastStockUpdate = LocalDateTime.now();
    }

    public boolean isProductAvailable(int quantityToCheck) {
        return quantityInStock >= quantityToCheck;
    }

    public double getInventoryValue() {
        return product.getPrice() * quantityInStock;
    }
}