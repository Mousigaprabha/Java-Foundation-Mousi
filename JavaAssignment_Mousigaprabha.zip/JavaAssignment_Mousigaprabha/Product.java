// Product.java
package entity;

public class Product {
    private int productID;
    private String productName;
    private String description;
    private double price;
    private String category;

    // Constructors
    public Product() {}

    public Product(int productID, String productName, String description, double price, String category) {
        this.productID = productID;
        this.productName = productName;
        this.description = description;
        this.price = price;
        this.category = category;
    }

    // Getters and setters with validation
    public int getProductID() { return productID; }
    public void setProductID(int productID) { this.productID = productID; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { 
        if (productName == null || productName.trim().isEmpty()) {
            throw new IllegalArgumentException("Product name cannot be empty");
        }
        this.productName = productName; 
    }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrice() { return price; }
    public void setPrice(double price) { 
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be negative");
        }
        this.price = price; 
    }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    // Methods
    public void getProductDetails() {
        System.out.println("Product ID: " + productID);
        System.out.println("Name: " + productName);
        System.out.println("Description: " + description);
        System.out.println("Price: $" + price);
        System.out.println("Category: " + category);
    }

    public void updateProductInfo(String description, double price) {
        setDescription(description);
        setPrice(price);
    }
}