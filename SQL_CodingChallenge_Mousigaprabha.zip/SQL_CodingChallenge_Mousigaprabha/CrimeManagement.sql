CREATE DATABASE CrimeManagement;
USE CrimeManagement;

CREATE TABLE Crime (
    CrimeID INT PRIMARY KEY,
    IncidentType VARCHAR(255),
    IncidentDate DATE,
    Location VARCHAR(255),
    Description TEXT,
    Status VARCHAR(20)
);

CREATE TABLE Victim (
    VictimID INT PRIMARY KEY,
    CrimeID INT,
    Name VARCHAR(255),
    ContactInfo VARCHAR(255),
    Injuries VARCHAR(255),
    Age INT,
    FOREIGN KEY (CrimeID) REFERENCES Crime(CrimeID)
);

CREATE TABLE Suspect (
    SuspectID INT PRIMARY KEY,
    CrimeID INT,
    Name VARCHAR(255),
    Description TEXT,
    CriminalHistory TEXT,
    Age INT,
    FOREIGN KEY (CrimeID) REFERENCES Crime(CrimeID)
);

INSERT INTO Crime (CrimeID, IncidentType, IncidentDate, Location, Description, Status)
VALUES
    (101, 'Robbery', '2023-09-15', '123 Main St, Cityville', 'Armed robbery at a convenience store', 'Open'),
    (102, 'Homicide', '2023-09-20', '456 Elm St, Townsville', 'Investigation into a murder case', 'Under Investigation'),
    (103, 'Theft' , '2023-09-10' , '789 Oak St, villagetown' , 'shoplifting incident at a mall' , 'Closed');

INSERT INTO Victim (VictimID, CrimeID, Name, ContactInfo, Injuries, Age)
VALUES
    (201, 101, 'John Doe', 'johndoe@example.com', 'Minor injuries', 32),
    (202, 102, 'Jane Smith', 'janesmith@example.com', 'Deceased', 35),
    (203, 103, 'Alice Johnson', 'alicejohnson@example.com', 'None', 30);

INSERT INTO Suspect (SuspectID, CrimeID, Name, Description, CriminalHistory, Age)
VALUES
    (301, 101, 'Robber 1', 'Armed and masked robber', 'Previous robbery convictions', 40),
    (302, 102, 'Unknown', 'Investigation ongoing', NULL, NULL),
    (303, 103, 'John Doe', 'Shoplifting suspect', 'Prior shoplifting arrests', 34);
-- 1
SELECT * FROM Crime WHERE Status = 'Open';

-- 2
SELECT COUNT(*) AS TotalIncidents FROM Crime;

-- 3
SELECT DISTINCT IncidentType FROM Crime;

-- 4
SELECT * FROM Crime 
WHERE IncidentDate BETWEEN '2023-09-01' AND '2023-09-10';

-- 5
SELECT Name, Age FROM Victim
UNION
SELECT Name, Age FROM Suspect
ORDER BY Age ASC;

-- 6
SELECT AVG(Age) AS AverageAge FROM (
    SELECT Age FROM Victim
    UNION ALL
    SELECT Age FROM Suspect
) AS AllPeople;

-- 7
SELECT IncidentType, COUNT(*) AS CaseCount 
FROM Crime
WHERE Status = 'Open'
GROUP BY IncidentType;
-- 8
SELECT Name FROM Victim WHERE Name LIKE '%Doe%'
UNION
SELECT Name FROM Suspect WHERE Name LIKE '%Doe%';

-- 9
SELECT V.Name, C.Status FROM Victim V
JOIN Crime C ON V.CrimeID = C.CrimeID
WHERE C.Status IN ('Open', 'Closed')
UNION
SELECT S.Name, C.Status FROM Suspect S
JOIN Crime C ON S.CrimeID = C.CrimeID
WHERE C.Status IN ('Open', 'Closed');

-- 10
SELECT DISTINCT C.IncidentType
FROM Crime C
JOIN Victim V ON C.CrimeID = V.CrimeID
WHERE V.Age IN (30, 35)
UNION
SELECT DISTINCT C.IncidentType
FROM Crime C
JOIN Suspect S ON C.CrimeID = S.CrimeID
WHERE S.Age IN (30, 35);

-- 11
SELECT DISTINCT V.Name FROM Victim V
JOIN Crime C ON V.CrimeID = C.CrimeID
WHERE C.IncidentType = 'Robbery'
UNION
SELECT DISTINCT S.Name FROM Suspect S
JOIN Crime C ON S.CrimeID = C.CrimeID
WHERE C.IncidentType = 'Robbery';
-- 12
SELECT IncidentType, COUNT(*) AS OpenCaseCount
FROM Crime
WHERE Status = 'Open'
GROUP BY IncidentType
HAVING COUNT(*) > 1;

-- 13
SELECT DISTINCT C.*
FROM Crime C
JOIN Suspect S ON C.CrimeID = S.CrimeID
WHERE S.Name IN (SELECT Name FROM Victim);

-- 14
SELECT C.CrimeID, C.IncidentType, V.Name AS Victim, S.Name AS Suspect
FROM Crime C
LEFT JOIN Victim V ON C.CrimeID = V.CrimeID
LEFT JOIN Suspect S ON C.CrimeID = S.CrimeID;

SELECT * FROM Victim WHERE Name = 'Jane smith';
-- 15
SELECT DISTINCT C.*
FROM Crime C
JOIN Suspect S ON C.CrimeID = S.CrimeID
WHERE S.Age > ALL (SELECT Age FROM Victim WHERE CrimeID = C.CrimeID);

-- 16
SELECT Name, COUNT(*) AS IncidentCount
FROM Suspect
GROUP BY Name
HAVING COUNT(*) > 1;

-- 17
SELECT * FROM Crime
WHERE CrimeID NOT IN (SELECT DISTINCT CrimeID FROM Suspect);

-- 18
SELECT CrimeID FROM Crime
WHERE IncidentType = 'Homicide'
AND NOT EXISTS (
    SELECT 1 FROM Crime
    WHERE IncidentType NOT IN ('Homicide', 'Robbery')
);

-- 19
SELECT C.CrimeID, C.IncidentType, COALESCE(S.Name, 'No Suspect') AS SuspectName
FROM Crime C
LEFT JOIN Suspect S ON C.CrimeID = S.CrimeID;

-- 20
SELECT DISTINCT S.Name FROM Suspect S
JOIN Crime C ON S.CrimeID = C.CrimeID
WHERE  C.IncidentType IN ('Robbery' , 'Assault');