package com.carrental.service;

import com.carrental.model.Car;
import com.carrental.exception.CarNotFoundException;

import java.util.ArrayList;
import java.util.List;

public class CarServiceImpl implements CarService {
    private List<Car> carList = new ArrayList<>();

    @Override
    public void addCar(Car car) {
        carList.add(car);
    }

    @Override
    public List<Car> getAllCars() {
        return carList;
    }

    @Override
    public Car getCarById(int id) {
        return carList.stream()
            .filter(car -> car.getId() == id)
            .findFirst()
            .orElseThrow(() -> new CarNotFoundException("Car ID " + id + " not found"));
    }

    @Override
    public void rentCar(int id) {
        Car car = getCarById(id);
        if (!car.isAvailable()) {
            throw new CarNotFoundException("Car ID " + id + " is already rented");
        }
        car.setAvailable(false);
    }
}