package com.carrental.service;

import com.carrental.model.Car;
import java.util.List;

public interface CarService {
    void addCar(Car car);
    List<Car> getAllCars();
    Car getCarById(int id);
    void rentCar(int id);
	void rentCar1(int carId)
}