CREATE TABLE Vehicle (
  vehicleID INT AUTO_INCREMENT,
  make VARCHAR(50) NOT NULL,
  model VARCHAR(50) NOT NULL,
  year INT NOT NULL,
  dailyRate DECIMAL(10, 2) NOT NULL,
  status ENUM('available', 'notAvailable') NOT NULL DEFAULT 'available',
  passengerCapacity INT NOT NULL,
  engineCapacity DECIMAL(5, 2) NOT NULL,
  PRIMARY KEY (vehicleID)
);

CREATE TABLE Customer (
  customerID INT AUTO_INCREMENT,
  firstName VARCHAR(50) NOT NULL,
  lastName VARCHAR(50) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  phoneNumber VARCHAR(20) NOT NULL,
  PRIMARY KEY (customerID)
);

CREATE TABLE Lease (
  leaseID INT AUTO_INCREMENT,
  vehicleID INT NOT NULL,
  customerID INT NOT NULL,
  startDate DATE NOT NULL,
  endDate DATE NOT NULL,
  type ENUM('DailyLease', 'MonthlyLease') NOT NULL,
  PRIMARY KEY (leaseID),
  FOREIGN KEY (vehicleID) REFERENCES Vehicle(vehicleID),
  FOREIGN KEY (customerID) REFERENCES Customer(customerID)
);

CREATE TABLE Payment (
  paymentID INT AUTO_INCREMENT,
  leaseID INT NOT NULL,
  paymentDate DATE NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  PRIMARY KEY (paymentID),
  FOREIGN KEY (leaseID) REFERENCES Lease(leaseID)
);
