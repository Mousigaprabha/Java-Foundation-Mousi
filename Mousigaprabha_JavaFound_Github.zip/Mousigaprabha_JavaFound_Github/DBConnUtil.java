package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import java.io.InputStream;

public class DBConnUtil {

    public static Connection getDBConn() throws Exception {
        Properties props = new Properties();
        InputStream input = DBConnUtil.class.getClassLoader().getResourceAsStream("db.properties");
        props.load(input);

        String url = props.getProperty("url");
        String user = props.getProperty("user");
        String password = props.getProperty("password");

        return DriverManager.getConnection(url, user, password);
    }

	public static void closeDBConn() {
		// TODO Auto-generated method stub
		
	}
}
