package main;

import dao.LoanRepositoryImpl;
import entity.*;
import exception.InvalidLoanException;

import java.util.List;
import java.util.Scanner;

@SuppressWarnings("unused")
public class MainModule {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LoanRepositoryImpl loanRepository = new LoanRepositoryImpl();

        int choice;
        do {
            System.out.println("\nLoan Management System Menu:");
            System.out.println("1. Apply for a Loan");
            // ... other menu options ...
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            try {
                switch (choice) {
                    case 1:
                        applyForLoan(scanner, loanRepository);
                        break;
                    // ... other cases ...
                }
            } catch (InvalidLoanException e) {
                System.err.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.err.println("An unexpected error occurred: " + e.getMessage());
            }
        } while (choice != 0);

        scanner.close();
        // DBConnUtil.closeDBConn(); // Ensure this is called appropriately
    }

    private static void applyForLoan(Scanner scanner, LoanRepositoryImpl loanRepository) throws Exception {
        System.out.println("\nApplying for a Loan:");
        System.out.print("Enter Customer Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Customer Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Customer Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter Customer Address: ");
        String address = scanner.nextLine();
        System.out.print("Enter Customer Credit Score: ");
        int creditScore = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Customer customer = new Customer(0, name, email, phone, address, creditScore);

        System.out.print("Enter Principal Amount: ");
        double principalAmount = scanner.nextDouble();
        System.out.print("Enter Interest Rate (annual): ");
        double interestRate = scanner.nextDouble();
        System.out.print("Enter Loan Term (in months): ");
        int loanTerm = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Loan Type (HomeLoan/CarLoan/Other): ");
        String loanType = scanner.nextLine();

        Loan loan = null;
        if (loanType.equalsIgnoreCase("HomeLoan")) {
            System.out.print("Enter Property Address: ");
            String propertyAddress = scanner.nextLine();
            System.out.print("Enter Property Value: ");
            int propertyValue = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            loan = new HomeLoan(0, customer, principalAmount, interestRate, loanTerm, loanType, "", propertyAddress, propertyValue);
        } else if (loanType.equalsIgnoreCase("CarLoan")) {
            System.out.print("Enter Car Model: ");
            String carModel = scanner.nextLine();
            System.out.print("Enter Car Value: ");
            int carValue = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            loan = new CarLoan(0, customer, principalAmount, interestRate, loanTerm, loanType, "", carModel, carValue);
        } else {
            loan = new Loan(0, customer, principalAmount, interestRate, loanTerm, loanType, "");
        }

        System.out.print("Confirm loan application? (Yes/No): "); // Line 28 where the error occurs
        String confirmation = scanner.nextLine().trim().toLowerCase();

        if (!confirmation.equals("yes")) {
            System.out.println("Loan application cancelled.");
            return; // Changed return false; to return; as the method is void now
        }

        // ... rest of your applyLoan logic ...
    }

    // ... other methods ...
}