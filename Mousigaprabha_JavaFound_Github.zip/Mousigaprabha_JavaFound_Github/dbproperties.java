url=jdbc:mysql://localhost:3306/your_database_name
user=root
password=root