package com.carrental.main;

import com.carrental.model.Car;
import com.carrental.service.CarService;
import com.carrental.service.CarServiceImpl;

import java.util.Scanner;

public class CarRentalApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CarService carService = new CarServiceImpl();

        // Sample cars
        carService.addCar(new Car(1, "Swift", "Maruti", 1200, true));
        carService.addCar(new Car(2, "i20", "Hyundai", 1500, true));
        carService.addCar(new Car(3, "City", "Honda", 1800, true));

        while (true) {
            System.out.println("\n--- Car Rental System ---");
            System.out.println("1. View Cars");
            System.out.println("2. Rent Car");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    carService.getAllCars().forEach(System.out::println);
                    break;
                case 2:
                    System.out.print("Enter Car ID to rent: ");
                    int carId = scanner.nextInt();
                    try {
                        carService.rentCar(carId);
                        System.out.println("Car rented successfully!");
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 3:
                    System.out.println("Thank you for using Car Rental System!");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}