package dao;

import entity.*;
import exception.InvalidLoanException;
import util.DBConnUtil;

import java.sql.*;
import java.util.*;

public class LoanRepositoryImpl implements ILoanRepository {

    private Connection conn;

    public LoanRepositoryImpl() {
        try {
            conn = DBConnUtil.getDBConn();
        } catch (Exception e) {
            e.printStackTrace();
            conn = null;
        }
    }

    @Override
    public boolean applyLoan(Loan loan) throws Exception {
        try (Scanner scanner = new Scanner(System.in)) {
			System.out.print("Confirm loan application? (Yes/No): ");
			String confirmation = scanner.nextLine().trim().toLowerCase();

			if (!confirmation.equals("yes")) {
			    System.out.println("Loan application cancelled.");
			    return false;
			}
		}
        try (PreparedStatement pstmtCustomer = conn.prepareStatement(
                     "INSERT INTO Customers (name, emailAddress, phoneNumber, address, creditScore) VALUES (?, ?, ?, ?, ?)",
                     Statement.RETURN_GENERATED_KEYS);
             PreparedStatement pstmtLoan = conn.prepareStatement(
                     "INSERT INTO Loans (customerId, principalAmount, interestRate, loanTerm, loanType, loanStatus, propertyAddress, propertyValue, carModel, carValue) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                     Statement.RETURN_GENERATED_KEYS)) {

            pstmtCustomer.setString(1, loan.getCustomer().getName());
            pstmtCustomer.setString(2, loan.getCustomer().getEmailAddress());
            pstmtCustomer.setString(3, loan.getCustomer().getPhoneNumber());
            pstmtCustomer.setString(4, loan.getCustomer().getAddress());
            pstmtCustomer.setInt(5, loan.getCustomer().getCreditScore());

            int affectedRowsCustomer = pstmtCustomer.executeUpdate();

            if (affectedRowsCustomer == 0) {
                System.out.println("Error applying loan: Could not add customer.");
                return false;
            }

            int customerId;
            try (ResultSet generatedKeys = pstmtCustomer.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    customerId = generatedKeys.getInt(1);
                    loan.getCustomer().setCustomerId(customerId);
                } else {
                    System.out.println("Error applying loan: Could not retrieve customer ID.");
                    return false;
                }
            }

            pstmtLoan.setInt(1, loan.getCustomer().getCustomerId());
            pstmtLoan.setDouble(2, loan.getPrincipalAmount());
            pstmtLoan.setDouble(3, loan.getInterestRate());
            pstmtLoan.setInt(4, loan.getLoanTerm());
            pstmtLoan.setString(5, loan.getLoanType());
            pstmtLoan.setString(6, "Pending");

            pstmtLoan.setString(7, (loan instanceof HomeLoan) ? ((HomeLoan) loan).getPropertyAddress() : null);
            pstmtLoan.setInt(8, (loan instanceof HomeLoan) ? ((HomeLoan) loan).getPropertyValue() : 0);
            pstmtLoan.setString(9, (loan instanceof CarLoan) ? ((CarLoan) loan).getCarModel() : null);
            pstmtLoan.setInt(10, (loan instanceof CarLoan) ? ((CarLoan) loan).getCarValue() : 0);

            int affectedRowsLoan = pstmtLoan.executeUpdate();

            if (affectedRowsLoan > 0) {
                try (ResultSet generatedKeysLoan = pstmtLoan.getGeneratedKeys()) {
                    if (generatedKeysLoan.next()) {
                        loan.setLoanId(generatedKeysLoan.getInt(1));
                        System.out.println("Loan application successful. Loan ID: " + loan.getLoanId());
                    } else {
                        System.out.println("Loan application successful, but could not retrieve Loan ID.");
                    }
                }
                return false;
            } else {
                System.out.println("Error applying loan: Could not add loan details.");
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Database error during loan application.");
            return false;
        }
    }

    @Override
    public double calculateInterest(int loanId) throws InvalidLoanException {
        try (PreparedStatement pstmt = conn.prepareStatement(
                     "SELECT principalAmount, interestRate, loanTerm FROM Loans WHERE loanId = ?")) {
            pstmt.setInt(1, loanId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    double principalAmount = rs.getDouble("principalAmount");
                    double interestRate = rs.getDouble("interestRate");
                    int loanTerm = rs.getInt("loanTerm");
                    return (principalAmount * interestRate * loanTerm) / 12;
                } else {
                    throw new InvalidLoanException("Loan with ID " + loanId + " not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Database error while calculating interest.");
            return 0;
        }
    }

    @Override
    public double calculateInterest(double principal, double rate, int term) {
        return (principal * rate * term) / 12;
    }

    @Override
    public void loanStatus(int loanId) throws InvalidLoanException {
        try (PreparedStatement pstmtSelectCustomer = conn.prepareStatement(
                     "SELECT c.creditScore FROM Loans l JOIN Customers c ON l.customerId = c.customerId WHERE l.loanId = ?");
             PreparedStatement pstmtUpdateStatus = conn.prepareStatement(
                     "UPDATE Loans SET loanStatus = ? WHERE loanId = ?")) {

            pstmtSelectCustomer.setInt(1, loanId);
            try (ResultSet rs = pstmtSelectCustomer.executeQuery()) {
                if (rs.next()) {
                    int creditScore = rs.getInt("creditScore");
                    String loanStatus = (creditScore > 650) ? "Approved" : "Rejected";
                    pstmtUpdateStatus.setString(1, loanStatus);
                    pstmtUpdateStatus.setInt(2, loanId);
                    int rowsUpdated = pstmtUpdateStatus.executeUpdate();
                    if (rowsUpdated > 0) {
                        System.out.println("Loan ID " + loanId + " is now " + loanStatus + ".");
                    } else {
                        System.out.println("Could not update the status for Loan ID " + loanId + ".");
                    }
                } else {
                    throw new InvalidLoanException("Loan with ID " + loanId + " not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Database error while updating loan status.");
        }
    }

    @Override
    public double calculateEMI(int loanId) throws InvalidLoanException {
        try (PreparedStatement pstmt = conn.prepareStatement(
                     "SELECT principalAmount, interestRate, loanTerm FROM Loans WHERE loanId = ?")) {
            pstmt.setInt(1, loanId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    double principalAmount = rs.getDouble("principalAmount");
                    double annualInterestRate = rs.getDouble("interestRate");
                    int loanTermMonths = rs.getInt("loanTerm");

                    double monthlyInterestRate = annualInterestRate / 12 / 100;
                    double powerFactor = Math.pow(1 + monthlyInterestRate, loanTermMonths);
                    return (principalAmount * monthlyInterestRate * powerFactor) / (powerFactor - 1);
                } else {
                    throw new InvalidLoanException("Loan with ID " + loanId + " not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Database error while calculating EMI.");
            return 0;
        }
    }

    @Override
    public double calculateEMI(double principal, double rate, int term) {
        double monthlyRate = rate / 12 / 100;
        double powerFactor = Math.pow(1 + monthlyRate, term);
        return (principal * monthlyRate * powerFactor) / (powerFactor - 1);
    }

    @Override
    public boolean loanRepayment(int loanId, double amount) throws InvalidLoanException {
        try (PreparedStatement pstmtSelect = conn.prepareStatement(
                     "SELECT principalAmount FROM Loans WHERE loanId = ?");
             PreparedStatement pstmtUpdate = conn.prepareStatement(
                     "UPDATE Loans SET principalAmount = ? WHERE loanId = ?")) {

            pstmtSelect.setInt(1, loanId);
            try (ResultSet rs = pstmtSelect.executeQuery()) {
                if (rs.next()) {
                    double currentPrincipal = rs.getDouble("principalAmount");
                    if (amount > currentPrincipal) {
                        amount = currentPrincipal; // Prevent negative principal
                    }
                    double remainingPrincipal = currentPrincipal - amount;
                    pstmtUpdate.setDouble(1, remainingPrincipal);
                    pstmtUpdate.setInt(2, loanId);
                    int rowsUpdated = pstmtUpdate.executeUpdate();
                    if (rowsUpdated > 0) {
                        System.out.println("Repayment of ₹" + amount + " successful for Loan ID " + loanId + ". Remaining principal: ₹" + String.format("%.2f", remainingPrincipal));
                        return false;
                    } else {
                        System.out.println("Could not process repayment for Loan ID " + loanId + ".");
                        return false;
                    }
                } else {
                    throw new InvalidLoanException("Loan with ID " + loanId + " not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Database error during loan repayment.");
            return false;
        }
    }

    @SuppressWarnings("rawtypes")
	@Override
    public List<Loan> getAllLoan()throws Exception {
        List<Loan> loans = new ArrayList<>();
        try (PreparedStatement pstmt = conn.prepareStatement(
                     "SELECT l., c. FROM Loans l JOIN Customers c ON l.customerId = c.customerId")) {
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Customer customer = new Customer(
                            rs.getInt("customerId"),
                            rs.getString("name"),
                            rs.getString("emailAddress"),
                            rs.getString("phoneNumber"),
                            rs.getString("address"),
                            rs.getInt("creditScore")
                    );

                    Loan loan;
                    String loanType = rs.getString("loanType");
                    if (loanType.equalsIgnoreCase("HomeLoan")) {
                        loan = new HomeLoan(
                                rs.getInt("loanId"),
                                customer,
                                rs.getDouble("principalAmount"),
                                rs.getDouble("interestRate"),
                                rs.getInt("loanTerm"),
                                loanType,
                                rs.getString("loanStatus"),
                                rs.getString("propertyAddress"),
                                rs.getInt("propertyValue")
                        );
                    } else if (loanType.equalsIgnoreCase("CarLoan")) {
                        loan = new CarLoan(
                                rs.getInt("loanId"),
                                customer,
                                rs.getDouble("principalAmount"),
                                rs.getDouble("interestRate"),
                                rs.getInt("loanTerm"),
                                loanType,
                                rs.getString("loanStatus"),
                                rs.getString("carModel"),
                                rs.getInt("carValue")
                        );
                    } else {
                        loan = new Loan(
                                rs.getInt("loanId"),
                                customer,
                                rs.getDouble("principalAmount"),
                                rs.getDouble("interestRate"),
                                rs.getInt("loanTerm"),
                                loanType,
                                rs.getString("loanStatus")
                        );
                    }
                    loans.add(loan);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Database error while fetching all loans.");
            return null; // Or throw a more specific exception
        }
		return loans;
    }

    @Override
    public Loan getLoanById(int loanId) throws InvalidLoanException {
        try (PreparedStatement pstmt = conn.prepareStatement(
                     "SELECT l., c. FROM Loans l JOIN Customers c ON l.customerId = c.customerId WHERE l.loanId = ?")) {
            pstmt.setInt(1, loanId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Customer customer = new Customer(
                            rs.getInt("customerId"),
                            rs.getString("name"),
                            rs.getString("emailAddress"),
                            rs.getString("phoneNumber"),
                            rs.getString("address"),
                            rs.getInt("creditScore")
                    );

                    String loanType = rs.getString("loanType");
                    if (loanType.equalsIgnoreCase("HomeLoan")) {
                        return new HomeLoan(
                                rs.getInt("loanId"),
                                customer,
                                rs.getDouble("principalAmount"),
                                rs.getDouble("interestRate"),
                                rs.getInt("loanTerm"),
                                loanType,
                                rs.getString("loanStatus"),
                                rs.getString("propertyAddress"),
                                rs.getInt("propertyValue")
                        );
                    } else if (loanType.equalsIgnoreCase("CarLoan")) {
                        return new CarLoan(
                                rs.getInt("loanId"),
                                customer,
                                rs.getDouble("principalAmount"),
                                rs.getDouble("interestRate"),
                                rs.getInt("loanTerm"),
                                loanType,
                                rs.getString("loanStatus"),
                                rs.getString("carModel"),
                                rs.getInt("carValue")
                        );
                    } else {
                        return new Loan(
                                rs.getInt("loanId"),
                                customer,
                                rs.getDouble("principalAmount"),
                                rs.getDouble("interestRate"),
                                rs.getInt("loanTerm"),
                                loanType,
                                rs.getString("loanStatus")
                        );
                    }
                } else {
                    throw new InvalidLoanException("Loan with ID " + loanId + " not found.");
                }
            }
        } 
        catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Database error while fetching loan by ID.");
            throw new Exception("Database error occurred while fetching loan by ID:" + e.getMessage());
           }
        }
    }

}